Memory Card Flip Game.
#How to play game
open Index.html in browser.
Timer will start and one counter for your steps taken will also be there.
Just click the box to flip the card, if two flipped card are the same in look, it will be flipped. else it will still in back.
You should take as fewer as possible steps to flip all cards, And than you will get a rank about the level of your memory.
If you will complete game in less number of steps star rating will be given to your candidature.
